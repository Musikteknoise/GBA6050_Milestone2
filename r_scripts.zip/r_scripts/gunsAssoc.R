#adjust this line to the folder where you will be saving this code and the data file
gun_data <- read.csv("final-gunData-2018.csv", header = T, colClasses = "factor")
gun <- gun_data
head(gun)

gun$incident_id <- NULL
gun$date <- NULL
gun$city_county <- NULL
gun$us_population <- NULL

head(gun)

library(arules)

rules = apriori(gun)
summary(rules)

rules20 <- apriori(gun, parameter = list(minlen = 2, maxlen = 3, supp = .3))

inspect(rules20)

#rules <- apriori(gun, appearance = list(rhs = c("open_carry=Permissive"), default="lhs"))
#summary(rules)

library(arulesViz)
plot(rules)
plot(rules20)

plot(rules20, method = "grouped")
plot(rules20, method = "graph", control = list(type="items"))

summary(rules20)
