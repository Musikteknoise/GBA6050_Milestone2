library(tidyverse)

gun_data <- read_csv("final-gunData-2018.csv")
per_capita <- read_csv("PerCapital.csv")

gun <- gun_data
per_cap <- per_capita

names(per_cap)
names(per_cap) <- c("state", "incidents", "pop", "ins_per_cap", "killed", "killed_per_cap", 
                    "injured", "injured_per_cap", "guns", "guns_per_cap")

ggplot(per_cap, aes (x= incidents, y = state, col = guns_per_cap, size = killed_per_cap)) +
  geom_point()

ggplot(gun) + geom_bar(mapping = aes(x=open_carry, fill = killed_injured))

ggplot(gun) + geom_bar(mapping = aes(x=killed_injured, fill = open_carry))

