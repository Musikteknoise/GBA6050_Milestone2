#load packages

library(tidyverse)
library(cluster)
library(factoextra)

#load data and create a data frame

per_capita <- read.csv("PerCapital.csv")

per_cap <- per_capita

head(per_cap)

names(per_cap) <- c("state", "incidents", "pop", "ins_per_cap", "killed", "killed_per_cap", 
                    "injured", "injured_per_cap", "guns", "guns_per_cap")

per_cap$state <- NULL
per_cap$pop <- NULL

head(per_cap)

#per Cap
per_cap$incidents <- NULL
per_cap$killed <- NULL
per_cap$injured <- NULL
per_cap$guns <- NULL

head(per_cap)

#clean data for DM
per_cap <- na.omit(per_cap)

# visualize
plot(per_cap)

#k-means clustering
k2 <- kmeans(per_cap, centers = 2, nstart = 25)
k3 <- kmeans(per_cap, centers = 3, nstart = 25)
k4 <- kmeans(per_cap, centers = 4, nstart = 25)
k5 <- kmeans(per_cap, centers = 5, nstart = 25)

k2
k3
k4
k5

k2$centers
k3$centers
k4$centers
k5$centers

# plots to compare
p1 <- fviz_cluster(k2, geom = "point", data = per_cap) + ggtitle("k = 2")
p2 <- fviz_cluster(k3, geom = "point",  data = per_cap) + ggtitle("k = 3")
p3 <- fviz_cluster(k4, geom = "point",  data = per_cap) + ggtitle("k = 4")
p4 <- fviz_cluster(k5, geom = "point",  data = per_cap) + ggtitle("k = 5")

library(gridExtra)
grid.arrange(p1, p2, p3, p4, nrow = 2)

set.seed(123)

fviz_nbclust(per_cap, kmeans, method = "wss")
